#!/usr/bin/env python3
"""
Academic Mini Project Report PDF Generator
Flight Booking and Seat Management System (Using Core Data Structures)
Author: Group 4 (Malhar Mahajan, Shubham Patil, Tejas Wable, Rohit Gondhali)
"""

import sys
import os

class SimplePDF:
    def __init__(self, filename="Project_Report.pdf", pagesize=(595.28, 841.89)):
        self.filename = filename
        self.width, self.height = pagesize  # A4: 595.28 x 841.89
        self.margin_x = 42
        self.printable_width = self.width - (2 * self.margin_x)  # ~511 pt
        self.margin_top = 45
        self.margin_bottom = 45
        
        self.pages = []
        self.current_stream = []
        self.y = self.height - self.margin_top
        self.page_number = 1
        
        # Approximate character widths for standard fonts at 10pt (in points)
        # Average char width ~ 5.5pt for Helvetica, ~6.0pt for Courier
        self.font_name = "F1"
        self.font_size = 10
        
    def new_page(self):
        if self.current_stream:
            self.pages.append("\n".join(self.current_stream))
            self.current_stream = []
        self.page_number += 1
        self.y = self.height - self.margin_top
        
        # Add running header on pages > 1
        self.set_color_stroke(0.75, 0.80, 0.85)
        self.set_line_width(0.5)
        self.draw_line(self.margin_x, self.height - 30, self.width - self.margin_x, self.height - 30)
        
        self.set_font("F3", 7.5)
        self.set_color_fill(0.40, 0.45, 0.50)
        self.draw_text_line(self.margin_x, self.height - 25, "Flight Booking & Seat Management System | Data Structures Mini Project")
        self.draw_text_line(self.width - self.margin_x - 100, self.height - 25, "Course: DSA Lab (2026-27)")

    def check_space(self, needed_pts):
        if self.y - needed_pts < self.margin_bottom:
            self.new_page()

    def set_font(self, font_name, size):
        self.font_name = font_name
        self.font_size = size
        self.current_stream.append(f"BT /{font_name} {size:.2f} Tf ET")

    def set_color_fill(self, r, g, b):
        self.current_stream.append(f"{r:.3f} {g:.3f} {b:.3f} rg")

    def set_color_stroke(self, r, g, b):
        self.current_stream.append(f"{r:.3f} {g:.3f} {b:.3f} RG")

    def set_line_width(self, w):
        self.current_stream.append(f"{w:.2f} w")

    def draw_line(self, x1, y1, x2, y2):
        self.current_stream.append(f"{x1:.2f} {y1:.2f} m {x2:.2f} {y2:.2f} l S")

    def draw_rect(self, x, y, w, h, fill=False, stroke=True):
        op = "B" if fill and stroke else ("f" if fill else "S")
        self.current_stream.append(f"{x:.2f} {y:.2f} {w:.2f} {h:.2f} re {op}")

    def draw_round_rect(self, x, y, w, h, r=4, fill=False, stroke=True):
        # Simplified rounded rectangle using box
        self.draw_rect(x, y, w, h, fill=fill, stroke=stroke)

    def escape_text(self, text):
        # Replace unicode characters with ASCII safe representation
        replacements = {
            "₹": "Rs. ",
            "—": " -- ",
            "–": "-",
            "“": '"',
            "”": '"',
            "’": "'",
            "‘": "'",
            "≤": "<=",
            "≥": ">=",
            "×": "x",
            "•": "*",
            "→": "->",
            "…": "...",
            "\u200b": ""
        }
        for k, v in replacements.items():
            text = text.replace(k, v)
        text = text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
        return text

    def draw_text_line(self, x, y, text):
        safe_text = self.escape_text(text)
        self.current_stream.append(f"BT /{self.font_name} {self.font_size:.2f} Tf {x:.2f} {y:.2f} Td ({safe_text}) Tj ET")

    def wrap_text(self, text, max_width_pt, font_size=None):
        if font_size is None:
            font_size = self.font_size
        char_width = font_size * 0.52
        chars_per_line = max(10, int(max_width_pt / char_width))
        
        words = text.split(" ")
        lines = []
        curr_line = []
        curr_len = 0
        
        for w in words:
            w_len = len(w)
            if curr_len + w_len + 1 <= chars_per_line:
                curr_line.append(w)
                curr_len += w_len + 1
            else:
                if curr_line:
                    lines.append(" ".join(curr_line))
                curr_line = [w]
                curr_len = w_len
        if curr_line:
            lines.append(" ".join(curr_line))
        return lines

    def add_title_header(self, dept, course, title, subtitle, group_members):
        self.check_space(240)
        
        # College / Dept Header
        self.set_font("F2", 10.5)
        self.set_color_fill(0.01, 0.41, 0.63)  # Teal blue
        self.draw_text_line(self.margin_x, self.y, dept.upper())
        self.y -= 14
        
        self.set_font("F1", 9)
        self.set_color_fill(0.35, 0.40, 0.45)
        self.draw_text_line(self.margin_x, self.y, course)
        self.y -= 18

        # Badge: Academic Mini Project Report
        self.set_color_fill(0.88, 0.95, 0.99)
        self.draw_rect(self.margin_x, self.y - 4, 190, 18, fill=True, stroke=False)
        self.set_font("F2", 8.5)
        self.set_color_fill(0.01, 0.41, 0.63)
        self.draw_text_line(self.margin_x + 8, self.y + 1, "ACADEMIC MINI PROJECT REPORT")
        self.y -= 22

        # Main Title
        self.set_font("F2", 16)
        self.set_color_fill(0.06, 0.09, 0.16)
        title_lines = self.wrap_text(title, self.printable_width, font_size=16)
        for tl in title_lines:
            self.draw_text_line(self.margin_x, self.y, tl)
            self.y -= 20
        self.y -= 2

        # Subtitle
        self.set_font("F3", 9)
        self.set_color_fill(0.35, 0.40, 0.45)
        sub_lines = self.wrap_text(subtitle, self.printable_width, font_size=9)
        for sl in sub_lines:
            self.draw_text_line(self.margin_x, self.y, sl)
            self.y -= 12
        self.y -= 10

        # Group Members Table
        self.set_font("F2", 9)
        self.set_color_fill(0.01, 0.41, 0.63)
        self.draw_text_line(self.margin_x, self.y, "PROJECT GROUP MEMBERS (GROUP OF 4):")
        self.y -= 14

        table_headers = ["Sr.", "Student Name", "Roll Number / ID", "Project Contribution / Role"]
        col_w = [28, 140, 110, 233]
        
        # Header Row
        self.set_color_fill(0.01, 0.41, 0.63)
        self.draw_rect(self.margin_x, self.y - 5, self.printable_width, 18, fill=True, stroke=False)
        self.set_font("F2", 8.5)
        self.set_color_fill(1, 1, 1)
        cur_x = self.margin_x
        for i, h in enumerate(table_headers):
            self.draw_text_line(cur_x + 6, self.y, h)
            cur_x += col_w[i]
        self.y -= 20

        # Rows
        for r_idx, (sr, name, roll, role) in enumerate(group_members):
            bg_col = (0.97, 0.98, 0.99) if r_idx % 2 == 0 else (1.0, 1.0, 1.0)
            self.set_color_fill(*bg_col)
            self.draw_rect(self.margin_x, self.y - 4, self.printable_width, 17, fill=True, stroke=False)
            
            # Border bottom
            self.set_color_stroke(0.85, 0.88, 0.92)
            self.set_line_width(0.5)
            self.draw_line(self.margin_x, self.y - 4, self.margin_x + self.printable_width, self.y - 4)

            self.set_color_fill(0.12, 0.16, 0.23)
            cur_x = self.margin_x
            
            self.set_font("F2", 8.5)
            self.draw_text_line(cur_x + 8, self.y + 1, str(sr))
            cur_x += col_w[0]
            
            self.set_font("F2", 8.5)
            self.draw_text_line(cur_x + 6, self.y + 1, name)
            cur_x += col_w[1]
            
            self.set_font("F2", 8.5)
            self.draw_text_line(cur_x + 6, self.y + 1, roll)
            cur_x += col_w[2]
            
            self.set_font("F1", 8)
            self.draw_text_line(cur_x + 6, self.y + 1, role)
            
            self.y -= 17

        # Decorative separator bar
        self.y -= 10
        self.set_color_stroke(0.01, 0.52, 0.78)
        self.set_line_width(1.5)
        self.draw_line(self.margin_x, self.y, self.margin_x + self.printable_width, self.y)
        self.y -= 14

    def add_section_heading(self, text):
        self.check_space(45)
        self.y -= 8
        self.set_font("F2", 12)
        self.set_color_fill(0.01, 0.41, 0.63)
        self.draw_text_line(self.margin_x, self.y, text.upper())
        self.y -= 4
        self.set_color_stroke(0.01, 0.52, 0.78)
        self.set_line_width(1.0)
        self.draw_line(self.margin_x, self.y, self.margin_x + self.printable_width, self.y)
        self.y -= 14

    def add_subheading(self, text):
        self.check_space(30)
        self.y -= 4
        self.set_font("F2", 10)
        self.set_color_fill(0.06, 0.09, 0.16)
        self.draw_text_line(self.margin_x, self.y, text)
        self.y -= 13

    def add_paragraph(self, text, prefix=""):
        lines = self.wrap_text(text, self.printable_width, font_size=9)
        self.check_space(len(lines) * 12 + 6)
        
        for i, line in enumerate(lines):
            self.set_font("F1", 9)
            self.set_color_fill(0.12, 0.16, 0.23)
            if i == 0 and prefix:
                self.set_font("F2", 9)
                self.draw_text_line(self.margin_x, self.y, prefix)
                # Draw the rest after prefix
                pref_len = len(prefix) * 5.2
                self.set_font("F1", 9)
                self.draw_text_line(self.margin_x + pref_len, self.y, line)
            else:
                self.draw_text_line(self.margin_x, self.y, line)
            self.y -= 12.5
        self.y -= 3

    def add_bullet(self, bold_prefix, text):
        full_text = f"{bold_prefix} {text}"
        lines = self.wrap_text(full_text, self.printable_width - 16, font_size=9)
        self.check_space(len(lines) * 12 + 4)
        
        # Bullet dot
        self.set_font("F2", 9)
        self.set_color_fill(0.01, 0.52, 0.78)
        self.draw_text_line(self.margin_x + 4, self.y, ">")
        
        for i, line in enumerate(lines):
            self.set_font("F1", 9)
            self.set_color_fill(0.12, 0.16, 0.23)
            self.draw_text_line(self.margin_x + 16, self.y, line)
            self.y -= 12
        self.y -= 2

    def add_callout_box(self, text, title=None):
        lines = self.wrap_text(text, self.printable_width - 24, font_size=8.5)
        h = len(lines) * 11.5 + (22 if title else 16)
        self.check_space(h + 8)
        
        box_y = self.y - h + 8
        self.set_color_fill(0.94, 0.97, 1.0)
        self.draw_rect(self.margin_x, box_y, self.printable_width, h, fill=True, stroke=False)
        
        # Left blue stripe
        self.set_color_fill(0.01, 0.52, 0.78)
        self.draw_rect(self.margin_x, box_y, 4, h, fill=True, stroke=False)
        
        curr_y = self.y
        if title:
            self.set_font("F2", 9)
            self.set_color_fill(0.01, 0.41, 0.63)
            self.draw_text_line(self.margin_x + 12, curr_y, title)
            curr_y -= 13
            
        for line in lines:
            self.set_font("F1", 8.5)
            self.set_color_fill(0.15, 0.20, 0.28)
            self.draw_text_line(self.margin_x + 12, curr_y, line)
            curr_y -= 11.5
            
        self.y = box_y - 8

    def add_table(self, headers, rows, col_widths):
        total_w = sum(col_widths)
        self.check_space(30 + len(rows) * 18)
        
        # Header Row
        self.set_color_fill(0.01, 0.41, 0.63)
        self.draw_rect(self.margin_x, self.y - 4, total_w, 18, fill=True, stroke=False)
        self.set_font("F2", 8)
        self.set_color_fill(1, 1, 1)
        cur_x = self.margin_x
        for i, h in enumerate(headers):
            self.draw_text_line(cur_x + 6, self.y, h)
            cur_x += col_w[i]
        self.y -= 19

        # Rows
        for r_idx, row in enumerate(rows):
            # calculate height needed for row if multi-line
            cell_lines = [self.wrap_text(str(c), col_widths[c_idx] - 10, font_size=8) for c_idx, c in enumerate(row)]
            max_lines = max(len(cl) for cl in cell_lines)
            row_h = max(16, max_lines * 10 + 6)
            
            self.check_space(row_h + 4)
            bg_col = (0.97, 0.98, 0.99) if r_idx % 2 == 0 else (1.0, 1.0, 1.0)
            self.set_color_fill(*bg_col)
            self.draw_rect(self.margin_x, self.y - row_h + 12, total_w, row_h, fill=True, stroke=False)
            
            # Bottom border
            self.set_color_stroke(0.85, 0.88, 0.92)
            self.set_line_width(0.5)
            self.draw_line(self.margin_x, self.y - row_h + 12, self.margin_x + total_w, self.y - row_h + 12)
            
            cur_x = self.margin_x
            for c_idx, cl in enumerate(cell_lines):
                line_y = self.y
                for l in cl:
                    self.set_font("F2" if c_idx == 0 or c_idx == len(row) - 1 else "F1", 7.5)
                    self.set_color_fill(0.12, 0.16, 0.23)
                    self.draw_text_line(cur_x + 5, line_y, l)
                    line_y -= 9.5
                cur_x += col_widths[c_idx]
            self.y -= row_h
        self.y -= 8

    def add_boarding_pass(self, lines):
        h = len(lines) * 10 + 16
        self.check_space(h + 10)
        
        box_y = self.y - h + 10
        self.set_color_fill(0.06, 0.09, 0.16)
        self.draw_rect(self.margin_x, box_y, self.printable_width, h, fill=True, stroke=False)
        
        curr_y = self.y
        for l in lines:
            self.set_font("F4", 7.5)  # Courier
            self.set_color_fill(0.22, 0.74, 0.97)  # Sky blue terminal
            self.draw_text_line(self.margin_x + 10, curr_y, l)
            curr_y -= 10
        self.y = box_y - 10

    def add_code_snippet(self, code_text):
        lines = code_text.split("\n")
        h = len(lines) * 9.5 + 14
        self.check_space(h + 8)
        
        box_y = self.y - h + 8
        self.set_color_fill(0.96, 0.97, 0.98)
        self.draw_rect(self.margin_x, box_y, self.printable_width, h, fill=True, stroke=False)
        self.set_color_stroke(0.80, 0.84, 0.88)
        self.set_line_width(0.7)
        self.draw_rect(self.margin_x, box_y, self.printable_width, h, fill=False, stroke=True)
        
        curr_y = self.y
        for l in lines:
            self.set_font("F4", 7.5)
            self.set_color_fill(0.10, 0.15, 0.25)
            self.draw_text_line(self.margin_x + 10, curr_y, l)
            curr_y -= 9.5
        self.y = box_y - 8

    def add_placeholder_box(self, title, description):
        h = 42
        self.check_space(h + 8)
        
        box_y = self.y - h + 8
        self.set_color_fill(0.97, 0.98, 0.99)
        self.draw_rect(self.margin_x, box_y, self.printable_width, h, fill=True, stroke=False)
        
        # Border
        self.set_color_stroke(0.65, 0.72, 0.80)
        self.set_line_width(0.8)
        self.draw_rect(self.margin_x, box_y, self.printable_width, h, fill=False, stroke=True)
        
        self.set_font("F2", 8.5)
        self.set_color_fill(0.20, 0.25, 0.35)
        self.draw_text_line(self.margin_x + 12, self.y, title)
        
        self.set_font("F1", 7.5)
        self.set_color_fill(0.40, 0.45, 0.55)
        self.draw_text_line(self.margin_x + 12, self.y - 12, description)
        
        self.y = box_y - 10

    def add_architecture_vector_diagram(self):
        h = 100
        self.check_space(h + 10)
        box_y = self.y - h + 10
        
        # 1. UI Layer Box
        self.set_color_fill(0.88, 0.95, 0.99)
        self.draw_rect(self.margin_x + 40, self.y - 18, self.printable_width - 80, 20, fill=True, stroke=False)
        self.set_color_stroke(0.01, 0.52, 0.78)
        self.set_line_width(1.0)
        self.draw_rect(self.margin_x + 40, self.y - 18, self.printable_width - 80, 20, fill=False, stroke=True)
        self.set_font("F2", 8)
        self.set_color_fill(0.01, 0.41, 0.63)
        self.draw_text_line(self.margin_x + 110, self.y - 13, "PRESENTATION LAYER: Modern Web Dashboard (Port 5050) & CLI Terminal")
        
        # Line from UI to Controller
        self.set_color_stroke(0.01, 0.52, 0.78)
        self.draw_line(self.margin_x + (self.printable_width / 2), self.y - 18, self.margin_x + (self.printable_width / 2), self.y - 30)

        # 2. Controller Box
        self.set_color_fill(0.94, 0.96, 0.98)
        self.draw_rect(self.margin_x + 80, self.y - 48, self.printable_width - 160, 18, fill=True, stroke=False)
        self.set_color_stroke(0.35, 0.40, 0.50)
        self.set_line_width(1.0)
        self.draw_rect(self.margin_x + 80, self.y - 48, self.printable_width - 160, 18, fill=False, stroke=True)
        self.set_font("F2", 8)
        self.set_color_fill(0.06, 0.09, 0.16)
        self.draw_text_line(self.margin_x + 130, self.y - 44, "FACADE CONTROLLER: FlightBookingManager")

        # Lines to 5 Data Structures
        mid_x = self.margin_x + (self.printable_width / 2)
        ds_y_top = self.y - 64
        self.set_color_stroke(0.55, 0.60, 0.68)
        self.set_line_width(0.8)
        
        boxes = [
            ("Doubly Linked List", "Confirmed Tickets", "O(1) Prepend"),
            ("Singly Linked Queue", "Waiting List", "O(1) FIFO"),
            ("LIFO Array Stack", "Cancellation Undo", "O(1) Undo"),
            ("1D Seat Matrix", "Seats 1-12 & Fares", "O(1) Index"),
            ("Binary Search Engine", "Fast PNR Lookup", "O(log N)")
        ]
        
        bw = (self.printable_width - 32) / 5
        for i, (b_title, b_sub, b_comp) in enumerate(boxes):
            bx = self.margin_x + i * (bw + 8)
            self.draw_line(mid_x, self.y - 48, bx + (bw / 2), ds_y_top + 16)
            
            # Draw DS Box
            self.set_color_fill(0.97, 0.98, 0.99)
            self.draw_rect(bx, ds_y_top - 20, bw, 36, fill=True, stroke=False)
            self.set_color_stroke(0.20, 0.45, 0.70)
            self.set_line_width(0.8)
            self.draw_rect(bx, ds_y_top - 20, bw, 36, fill=False, stroke=True)
            
            self.set_font("F2", 6.5)
            self.set_color_fill(0.01, 0.41, 0.63)
            self.draw_text_line(bx + 4, ds_y_top + 6, b_title)
            
            self.set_font("F1", 6)
            self.set_color_fill(0.25, 0.30, 0.38)
            self.draw_text_line(bx + 4, ds_y_top - 4, b_sub)
            
            self.set_font("F2", 6)
            self.set_color_fill(0.10, 0.60, 0.30)
            self.draw_text_line(bx + 4, ds_y_top - 14, b_comp)

        self.y = box_y - 8

    def build_pdf(self):
        # Save last page
        if self.current_stream:
            self.pages.append("\n".join(self.current_stream))
            self.current_stream = []

        total_pages = len(self.pages)
        
        # Inject Page Numbers in Footers
        final_pages_data = []
        for p_idx, p_content in enumerate(self.pages, 1):
            footer_stream = [
                f"BT /F1 8 Tf 0.40 0.45 0.50 rg",
                f"{self.margin_x:.2f} 25 Td (Flight Booking and Seat Management System | Mini Project Report) Tj",
                f"ET",
                f"BT /F2 8 Tf 0.01 0.41 0.63 rg",
                f"{(self.width - self.margin_x - 65):.2f} 25 Td (Page {p_idx} of {total_pages}) Tj",
                f"ET",
                f"0.75 0.80 0.85 RG 0.5 w",
                f"{self.margin_x:.2f} 35 m {(self.width - self.margin_x):.2f} 35 l S"
            ]
            final_pages_data.append(p_content + "\n" + "\n".join(footer_stream))

        # Generate PDF objects
        objects = []
        
        # 1: Catalog
        objects.append("<< /Type /Catalog /Pages 2 0 R >>")
        
        # 2: Pages Parent
        kids_refs = " ".join([f"{3 + i * 2} 0 R" for i in range(total_pages)])
        objects.append(f"<< /Type /Pages /Kids [{kids_refs}] /Count {total_pages} >>")

        # Fonts
        # 3 + total_pages * 2 will be fonts
        font_obj_start = 3 + total_pages * 2
        font_defs = {
            "F1": "/Helvetica",
            "F2": "/Helvetica-Bold",
            "F3": "/Helvetica-Oblique",
            "F4": "/Courier",
            "F5": "/Courier-Bold"
        }
        
        # Page Objects and Content Streams
        for i in range(total_pages):
            page_obj_id = 3 + i * 2
            content_obj_id = 4 + i * 2
            
            font_resources = " ".join([f"/{fname} {font_obj_start + f_idx} 0 R" for f_idx, fname in enumerate(font_defs)])
            page_dict = f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {self.width:.2f} {self.height:.2f}] /Resources << /Font << {font_resources} >> >> /Contents {content_obj_id} 0 R >>"
            objects.append(page_dict)
            
            stream_bytes = final_pages_data[i].encode("latin1", "replace")
            content_dict = f"<< /Length {len(stream_bytes)} >>\nstream\n{final_pages_data[i]}\nendstream"
            objects.append(content_dict)

        # Append Font objects
        for fname, basefont in font_defs.items():
            objects.append(f"<< /Type /Font /Subtype /Type1 /BaseFont {basefont} >>")

        # Write PDF File
        with open(self.filename, "wb") as f:
            f.write(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
            offsets = []
            
            for idx, obj in enumerate(objects, 1):
                offsets.append(f.tell())
                f.write(f"{idx} 0 obj\n{obj}\nendobj\n".encode("latin1", "replace"))
                
            xref_pos = f.tell()
            f.write(f"xref\n0 {len(objects) + 1}\n".encode("latin1"))
            f.write(b"0000000000 65535 f \n")
            for off in offsets:
                f.write(f"{off:010d} 00000 n \n".encode("latin1"))
                
            trailer = f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref_pos}\n%%EOF\n"
            f.write(trailer.encode("latin1"))

        print(f"Generated {self.filename} successfully ({total_pages} pages).")


def build_full_report_pdf():
    pdf = SimplePDF(filename="/Users/malharmahajan/Desktop/DSPROJECT/Project_Report.pdf")

    # Cover & Header
    group = [
        (1, "Malhar Mahajan", "25108B0029", "Project Lead, Doubly Linked List & Web Interface Integration"),
        (2, "Shubham Patil", "25108B0005", "Waiting List FIFO Queue & Seat Allocation Matrix"),
        (3, "Tejas Wable", "25108B0004", "Cancellation LIFO Stack & Multi-Step Undo Mechanism"),
        (4, "Rohit Gondhali", "25108B0031", "Binary Search Engine, Multi-Key Sorting & Testing Suite")
    ]
    
    pdf.add_title_header(
        dept="Department of Computer Engineering / Information Technology",
        course="Course: Data Structures and Algorithms Laboratory | Academic Year: 2026-2027",
        title="Flight Booking and Seat Management System",
        subtitle="An Algorithmic Passenger Reservation & Inventory System Implemented with Fundamental Data Structures",
        group_members=group
    )

    # 1. Abstract
    pdf.add_section_heading("1. Abstract")
    pdf.add_callout_box(
        "Modern airline passenger reservation systems necessitate low-latency, deterministic data handling for ticket reservations, seat category allocation, cancellations, and waiting list updates. This project presents the design and implementation of a robust Flight Booking and Seat Management System engineered in Python using purely native, foundational data structures without relying on high-level database engines or external third-party collection libraries. The system utilizes: (1) A Doubly Linked List with an O(1) prepend operation to store confirmed passengers and immediately display newest bookings at the top; (2) A FIFO Singly Linked Queue with front and rear pointers to manage fair passenger waitlisting and automated promotion upon seat cancellation; (3) A Fixed-Capacity LIFO Stack to record cancellations and provide multi-level undo functionality; (4) A 1D Array Representation for dynamic seat inventory tracking across Window (Rs. 1,200), Middle (Rs. 1,000), and Aisle (Rs. 900) tiers; and (5) Optimized Binary Search (O(log N)) and Insertion/Bubble Sort routines for rapid passenger lookups by PNR, Name, and Age. Evaluated through both a terminal CLI and an interactive, responsive Web Dashboard running on Python's built-in HTTP server, the system successfully demonstrates complete transaction atomicity, real-time ticket generation, and zero data inconsistency under boundary constraints.",
        title="PROJECT EXECUTIVE SUMMARY"
    )

    # 2. Introduction
    pdf.add_section_heading("2. Introduction")
    pdf.add_subheading("2.1 Problem Statement")
    pdf.add_paragraph(
        "Commercial flight reservation processes encounter severe operational bottlenecks when processing high-frequency transactions involving seat selection, queue transitions, and last-minute cancellations. Standard enterprise implementations often introduce unnecessary overhead when modeling atomic, in-memory state changes. The primary challenge is to construct an in-memory passenger reservation and inventory control engine that satisfies strict algorithmic time and space complexity constraints:"
    )
    pdf.add_bullet("O(1) Prepend Access:", "Instantaneous priority addition and chronological head-placement of newly reserved tickets.")
    pdf.add_bullet("Fair Queue Scheduling:", "Strictly fair, starvation-free First-In-First-Out (FIFO) queue handling for passenger overflow.")
    pdf.add_bullet("Reversible Transactions:", "Reversible Last-In-First-Out (LIFO) transaction rollbacks for ticket cancellation undos.")
    pdf.add_bullet("Seat Matrix & Pricing:", "Real-time seat inventory mapping with category-based fare computing.")

    pdf.add_subheading("2.2 Project Objectives")
    pdf.add_bullet("1.", "Pure Data Structure Design: Implement all core data storage components from scratch using foundational pointer references.")
    pdf.add_bullet("2.", "Automated Queue Promotion: Promote the front waitlisted passenger into confirmed status immediately when a seat is cancelled.")
    pdf.add_bullet("3.", "Cabin Matrix & Fares: Segment cabin into Window (Rs. 1,200), Middle (Rs. 1,000), and Aisle (Rs. 900) tiers.")
    pdf.add_bullet("4.", "Fast Searching & Sorting: Enable O(log N) Binary Search on PNRs and dynamic sorting by Age and Name.")
    pdf.add_bullet("5.", "Interactive Interfaces: Provide a modern Web Dashboard (HTTP server on Port 5050) and a comprehensive CLI.")

    # 3. System Analysis & Design
    pdf.new_page()
    pdf.add_section_heading("3. System Analysis & Design")
    pdf.add_subheading("3.1 System Architecture Diagram")
    pdf.add_architecture_vector_diagram()

    pdf.add_subheading("3.2 Data Structure Mapping & Complexity Analysis")
    ds_headers = ["Module / Feature", "Chosen Data Structure", "Primary Mechanism", "Time", "Space"]
    global col_w
    col_w = [115, 125, 150, 60, 61]
    ds_rows = [
        ["Confirmed Passengers", "Doubly Linked List (TicketList)", "Head Prepend & Pointer Relinking", "O(1) Insert", "O(N)"],
        ["Waiting List Overflow", "Singly Linked Queue (Queue)", "Head Dequeue & Tail Enqueue", "O(1) FIFO", "O(W)"],
        ["Cancellation Undo Stack", "Array Stack (Stack)", "Top Pointer Increment/Decrement", "O(1) Undo", "O(K)"],
        ["Seat Inventory & Fares", "1D Array (SeatMap)", "Direct Indexing seats[seat_no-1]", "O(1) Lookup", "O(1) [12]"],
        ["PNR Search Engine", "Sorted Array (BinarySearch)", "Divide and Conquer Search", "O(log N)", "O(1) aux"],
        ["Manifest Sort", "In-place Bubble/Insertion Sort", "Pairwise comparison & swaps", "O(N^2)", "O(1) aux"]
    ]
    pdf.add_table(ds_headers, ds_rows, col_w)

    # 4. Implementation Details
    pdf.add_section_heading("4. Implementation & Module Details")
    pdf.add_subheading("4.1 Confirmed Passenger Storage via Doubly Linked List (confirmed_tickets.py)")
    pdf.add_paragraph(
        "Standard dynamic arrays require O(N) element shifting when inserting at index 0. To guarantee that newly booked passengers appear immediately at the top of the confirmed manifest in O(1) time, a Doubly Linked List is employed. Each TicketNode maintains record data, prev node pointer, and next node pointer."
    )
    code = (
        "def prepend(self, record):\n"
        "    \"\"\"Inserts newly booked passenger at the head of the list in O(1) time.\"\"\"\n"
        "    new_node = TicketNode(record)\n"
        "    if self.is_empty():\n"
        "        self.head = self.tail = new_node\n"
        "    else:\n"
        "        new_node.next = self.head\n"
        "        self.head.prev = new_node\n"
        "        self.head = new_node\n"
        "    self._size += 1"
    )
    pdf.add_code_snippet(code)

    pdf.add_subheading("4.2 FIFO Waiting List via Singly Linked Queue (waiting_queue.py)")
    pdf.add_paragraph(
        "Overbooked passengers beyond the 12-seat capacity are queued into a Singly Linked Queue. Separate head_node and tail_node pointers guarantee O(1) enqueue and dequeue operations. When any confirmed seat is cancelled, the head passenger is dequeued and promoted automatically."
    )

    pdf.add_subheading("4.3 Cancellation History and Undo via Array Stack (cancellation_stack.py)")
    pdf.add_paragraph(
        "A fixed-size array stack implements LIFO rollback semantics. Whenever a ticket is cancelled, its snapshot is pushed onto the stack. Invoking Undo pops the top record, verifies seat availability, and restores the passenger."
    )

    pdf.add_subheading("4.4 Cabin Layout & Dynamic Pricing (seat_allocation.py)")
    pdf.add_bullet("Window Seats (1, 4, 7, 10, 3, 6, 9, 12):", "Rs. 1,200 (Highest passenger preference).")
    pdf.add_bullet("Middle Seats (2, 5, 8, 11):", "Rs. 1,000 (Standard economy comfort).")
    pdf.add_bullet("Aisle Classification:", "Rs. 900 (Fast cabin egress). Total Full Cabin Inventory Revenue: Rs. 12,400.")

    # 5. Results & Discussion
    pdf.new_page()
    pdf.add_section_heading("5. Results and Discussion")
    pdf.add_subheading("5.1 Verification Test Cases & Execution Summary")
    tc_headers = ["ID", "Test Case Description", "Input Data", "Expected Output", "Status"]
    col_w = [35, 120, 130, 175, 51]
    tc_rows = [
        ["TC-01", "Booking Available Seat", "Malhar, Age 20, Seat 7", "Seat 7 allocated (Rs. 1,200), PNR AI-1001 generated, node prepended.", "PASS"],
        ["TC-02", "Confirmed Order Check", "New passenger booking", "New booking displays as Row #1 in manifest table (O(1) prepend).", "PASS"],
        ["TC-03", "Flight Saturation", "13th passenger booking attempt", "Capacity full prompt; passenger enqueued as WAITLISTED (WL-1).", "PASS"],
        ["TC-04", "Auto Waitlist Promotion", "Cancel confirmed ticket (Seat 3)", "Seat 3 freed; front waitlisted passenger promoted and allocated Seat 3.", "PASS"],
        ["TC-05", "Undo Cancellation", "Click Undo Cancellation", "Most recently cancelled ticket popped from stack and re-confirmed.", "PASS"],
        ["TC-06", "Binary Search on PNR", "Search PNR AI-1007", "Record located in <= 4 comparisons using O(log N) Binary Search.", "PASS"]
    ]
    pdf.add_table(tc_headers, tc_rows, col_w)

    pdf.add_subheading("5.2 Sample Boarding Pass Generation")
    bp = [
        "================================================================================",
        "                        AIRWAYS BOARDING PASS",
        "================================================================================",
        " PASSENGER NAME : Malhar Mahajan                  PNR NO     : AI-1007",
        " AGE            : 20 Years                        SEAT NO    : 07 (Window)",
        " FLIGHT         : AI-204 (Mumbai to Delhi)        STATUS     : CONFIRMED",
        " BOARDING TIME  : 09:30 AM                        GATE       : G-04",
        " FARE PAID      : INR 1,200                       CLASS      : Economy Standard",
        "================================================================================",
        " Please be at the boarding gate at least 45 minutes prior to departure.",
        "================================================================================"
    ]
    pdf.add_boarding_pass(bp)

    pdf.add_subheading("5.3 Visual Verification & UI Screenshot Placement Guides")
    pdf.add_placeholder_box(
        "[SCREENSHOT 1: INTERACTIVE CABIN SEAT MATRIX & PRICING DASHBOARD]",
        "Displays 12-seat aircraft layout, live occupancy color badges (Green=Available, Red=Occupied, Amber=Selected), and fares."
    )
    pdf.add_placeholder_box(
        "[SCREENSHOT 2: CONFIRMED PASSENGERS MANIFEST (NEWEST BOOKINGS FIRST)]",
        "Displays confirmed manifest showing new bookings prepended to Row #1 with PNR, Name, Age, Seat, Fare, and Cancel button."
    )
    pdf.add_placeholder_box(
        "[SCREENSHOT 3: WAITING LIST QUEUE & CANCELLATION STACK]",
        "Displays live FIFO Waiting List table and Undo Cancellation action button reflecting real-time stack counter."
    )

    # 6. Conclusion & Future Scope
    pdf.add_section_heading("6. Conclusion and Future Scope")
    pdf.add_subheading("6.1 Conclusion")
    pdf.add_paragraph(
        "The Flight Booking and Seat Management System successfully demonstrates that foundational computer science data structures (Doubly Linked Lists, Singly Linked Queues, Array Stacks, and Direct-Index Arrays) can form a robust, high-performance airline reservation engine without relying on opaque databases. The application guarantees fair waitlist management, O(1) recent booking access, reversible cancellations, and O(log N) search lookups."
    )
    pdf.add_subheading("6.2 Future Scope")
    pdf.add_bullet("Connecting Flights:", "Extend routing to multi-sector flights using Directed Acyclic Graphs (DAG).")
    pdf.add_bullet("Persistent Disk Storage:", "Implement serialized B-Tree file persistence across application restarts.")
    pdf.add_bullet("Dynamic Surge Pricing:", "Implement real-time demand-based surge pricing algorithms using Min/Max Heaps.")

    # 7. References
    pdf.add_section_heading("7. References")
    pdf.add_bullet("1.", "Horowitz, E., Sahni, S., & Anderson-Freed, S., Fundamentals of Data Structures in C, 2nd Edition, Universities Press, 2008.")
    pdf.add_bullet("2.", "Cormen, T. H., Leiserson, C. E., Rivest, R. L., & Stein, C., Introduction to Algorithms, 3rd Edition, MIT Press, 2009.")
    pdf.add_bullet("3.", "Goodrich, M. T., Tamassia, R., & Goldwasser, M. H., Data Structures and Algorithms in Python, John Wiley & Sons, 2013.")
    pdf.add_bullet("4.", "Python Software Foundation, Python Standard Library Documentation (Built-in Types & http.server), https://docs.python.org/3/library/")

    pdf.build_pdf()

if __name__ == "__main__":
    build_full_report_pdf()
